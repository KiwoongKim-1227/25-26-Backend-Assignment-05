package com.example.oauthgoogleloginexample.domain;

public enum UserRole {
    USER, ADMIN
}
